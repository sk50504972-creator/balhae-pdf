const ADOBE = 'efaidnbmnnnibpcajpcglclefindmkaj';
document.getElementById('ver').textContent = chrome.runtime.getManifest().version;
document.getElementById('open').onclick = () => chrome.tabs.create({ url: 'https://balhae.claimworks.kr/balhae-pdf/' });
const cb = document.getElementById('takeover');
chrome.storage.local.get('takeover').then(s => { cb.checked = s.takeover !== false; });
cb.onchange = () => chrome.storage.local.set({ takeover: cb.checked });
async function adobe() {
  const t = document.getElementById('adobeTxt'), b = document.getElementById('adobeBtn');
  try {
    const x = await chrome.management.get(ADOBE);
    if (x.enabled) { t.innerHTML = '<span class="warn">Adobe Acrobat 확장이 켜져 있습니다.</span>'; b.textContent = 'Adobe Acrobat 확장 끄기'; b.className = 'primary'; b.hidden = false; b.onclick = async () => { await chrome.management.setEnabled(ADOBE, false); adobe(); }; }
    else { t.innerHTML = '<span class="ok">Adobe Acrobat 확장이 꺼져 있습니다.</span>'; b.textContent = 'Adobe 확장 다시 켜기'; b.className = ''; b.hidden = false; b.onclick = async () => { await chrome.management.setEnabled(ADOBE, true); adobe(); }; }
  } catch { t.innerHTML = '<span class="ok">Adobe Acrobat 확장이 설치되어 있지 않습니다.</span>'; b.hidden = true; }
}
adobe();
