const APP_ORIGIN = 'https://balhae.claimworks.kr';
const frame = document.getElementById('app');
const src = new URLSearchParams(location.search).get('file');
const handles = new Map(); let hseq = 0;
function show(t) { const m = document.getElementById('msg'); m.textContent = t; m.style.display = t ? 'block' : 'none'; }
function nameFrom(url, cd) {
  let n = '';
  const m1 = /filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)/.exec(cd || ''); const m2 = /filename\s*=\s*"?([^";]+)"?/i.exec(cd || '');
  try { n = m1 ? decodeURIComponent(m1[1]) : m2 ? m2[1] : decodeURIComponent(new URL(url).pathname.split('/').pop() || ''); } catch { n = ''; }
  if (!n) n = 'document.pdf'; if (!/\.pdf$/i.test(n)) n += '.pdf';
  return n;
}
function readFileUrl(url) {
  return new Promise((res, rej) => { const x = new XMLHttpRequest(); x.open('GET', url); x.responseType = 'arraybuffer'; x.onload = () => res(x.response); x.onerror = () => rej(new Error('내 PC 파일을 읽지 못했습니다. 확장 프로그램 세부정보에서 「파일 URL에 대한 액세스 허용」을 켜 주세요.')); x.send(); });
}
async function load(url) {
  if (url.startsWith('file:')) return { name: nameFrom(url), type: 'application/pdf', buffer: await readFileUrl(url) };
  const r = await fetch(url, { credentials: 'include' });
  if (!r.ok) throw new Error('PDF를 받지 못했습니다 (' + r.status + ')');
  return { name: nameFrom(url, r.headers.get('content-disposition')), type: 'application/pdf', buffer: await r.arrayBuffer() };
}
const pending = src ? load(src) : null;
if (src) document.title = '불러오는 중 - 발해 PDF';
function reply(d, data, transfer) { frame.contentWindow.postMessage({ reqId: d.reqId, ...data }, APP_ORIGIN, transfer || []); }
addEventListener('message', async e => {
  if (e.origin !== APP_ORIGIN || e.source !== frame.contentWindow) return;
  const d = e.data || {};
  if (d.type === 'balhae-ready' && pending) {
    try { const f = await pending; const copy = f.buffer.slice(0); frame.contentWindow.postMessage({ type: 'balhae-open', files: [{ name: f.name, type: f.type, buffer: copy }] }, APP_ORIGIN, [copy]); }
    catch (err) { frame.contentWindow.postMessage({ type: 'balhae-error', message: String(err.message || err) + ' 원래 주소: ' + src }, APP_ORIGIN); }
  }
  if (d.type === 'balhae-title' && d.title) document.title = d.title;
  if (d.type === 'balhae-pick') {
    try {
      const h = await showSaveFilePicker({ suggestedName: d.name, types: [{ description: 'PDF 문서', accept: { 'application/pdf': ['.pdf'] } }] });
      const id = ++hseq; handles.set(id, h); reply(d, { ok: true, id, name: h.name });
    } catch (err) { reply(d, { ok: false, abort: err && err.name === 'AbortError', message: String(err && err.message) }); }
  }
  if (d.type === 'balhae-write') {
    try { const h = handles.get(d.id); const w = await h.createWritable(); await w.write(d.buffer); await w.close(); reply(d, { ok: true }); }
    catch (err) { reply(d, { ok: false, message: String(err && err.message || err) }); }
  }
});
frame.addEventListener('load', () => show(''));
setTimeout(() => { if (!navigator.onLine) show('인터넷에 연결되어 있지 않습니다. 연결 후 새로고침(F5) 하세요.'); }, 3000);
