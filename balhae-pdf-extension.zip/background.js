// 발해 PDF 편집기 확장: 크롬에서 열리는 PDF를 발해 PDF 편집기로 연다
const VIEWER = chrome.runtime.getURL('viewer.html');
const APP = 'https://balhae.claimworks.kr/balhae-pdf/';
const viewerUrl = u => VIEWER + '?file=' + encodeURIComponent(u);
const on = async () => (await chrome.storage.local.get('takeover')).takeover !== false;

chrome.runtime.onInstalled.addListener(async () => {
  const s = await chrome.storage.local.get('takeover');
  if (s.takeover === undefined) await chrome.storage.local.set({ takeover: true });
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'open-link', title: '발해 PDF 편집기로 열기', contexts: ['link'] });
    chrome.contextMenus.create({ id: 'open-page', title: '이 PDF를 발해 PDF 편집기로 열기', contexts: ['page'] });
  });
});
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const u = info.linkUrl || info.pageUrl;
  if (u) chrome.tabs.create({ url: viewerUrl(u), index: tab ? tab.index + 1 : undefined });
});

// 웹의 PDF (Content-Type: application/pdf, 다운로드가 아닌 것)
chrome.webRequest.onHeadersReceived.addListener(d => {
  if (d.tabId < 0 || d.method !== 'GET' || d.statusCode < 200 || d.statusCode >= 300) return;
  if (d.url.startsWith(APP) || d.url.startsWith('chrome')) return;
  const h = {};
  for (const x of d.responseHeaders || []) h[x.name.toLowerCase()] = x.value || '';
  if (!(h['content-type'] || '').toLowerCase().includes('application/pdf')) return;
  if (/^\s*attachment/i.test(h['content-disposition'] || '')) return;
  on().then(ok => { if (ok) chrome.tabs.update(d.tabId, { url: viewerUrl(d.url) }); });
}, { urls: ['<all_urls>'], types: ['main_frame'] }, ['responseHeaders']);

// 내 PC의 PDF를 크롬으로 연 경우 (file://, 확장 설정에서 '파일 URL에 대한 액세스 허용' 필요)
chrome.tabs.onUpdated.addListener((tabId, info) => {
  const u = info.url;
  if (!u || !/^file:\/\/.+\.pdf$/i.test(u)) return;
  on().then(ok => { if (ok) chrome.tabs.update(tabId, { url: viewerUrl(u) }); });
});
